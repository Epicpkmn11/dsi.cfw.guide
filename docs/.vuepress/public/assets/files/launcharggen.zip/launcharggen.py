import os
import shutil
successful_launchargs = 0

print("LaunchArg Helper by jerbear64 and Jhynjhiruu (edited by Robz8)")
if os.path.exists("dsiware"): shutil.rmtree("dsiware")
os.mkdir("dsiware")

for app in os.listdir(os.getcwd()):
    try:       
        for title in os.listdir(app + "/content/"):
            if title.endswith(".app"):
                print("Found app at /{0}/content/{1}\nGenerating launcharg...".format(app, title))
                with open("dsiware/{}.launcharg".format(app), "w") as launcharg: launcharg.write("sd:/title/00030004/" + app)
                successful_launchargs = successful_launchargs + 1
    except:pass 
print("Generated launchargs for {} title(s) successfully".format(successful_launchargs))
